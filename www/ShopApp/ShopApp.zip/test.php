<html>
<title>login2<title>
<body>
<?php
//$usr = "root";
//$pas = "password";
$username = '$_POST[username]';
$password = '$_POST[password]';



 ?>

</body>

</html>